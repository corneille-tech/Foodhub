package com.example

import com.example.foodhub.data.model.CartItem
import com.example.foodhub.data.model.MenuItemEntity
import com.example.foodhub.data.model.OrderStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class FoodHubLogicTest {

  @Test
  fun `order status transitions follow digital journey`() {
    val pending = OrderStatus.PENDING
    val confirmed = pending.nextStatus()
    assertEquals(OrderStatus.CONFIRMED, confirmed)

    val preparing = confirmed?.nextStatus()
    assertEquals(OrderStatus.PREPARING, preparing)

    val outForDelivery = preparing?.nextStatus()
    assertEquals(OrderStatus.OUT_FOR_DELIVERY, outForDelivery)

    val delivered = outForDelivery?.nextStatus()
    assertEquals(OrderStatus.DELIVERED, delivered)
    assertEquals(null, delivered?.nextStatus())
  }

  @Test
  fun `cart item calculation is accurate`() {
    val sampleItem = MenuItemEntity(
      id = 1L,
      name = "Artisan Truffle Burger",
      category = "Burgers",
      description = "Juicy gourmet beef patty",
      price = 14.50,
      isAvailable = true,
      isPopular = true,
      prepTimeMinutes = 15,
      rating = 4.9,
      calories = 680,
      tags = "Chef Choice"
    )

    val cartItem = CartItem(
      menuItem = sampleItem,
      quantity = 3,
      specialInstructions = "No onions"
    )

    assertEquals(43.50, cartItem.totalPrice, 0.001)
  }
}
