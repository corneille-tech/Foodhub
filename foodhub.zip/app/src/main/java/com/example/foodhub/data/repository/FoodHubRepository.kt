package com.example.foodhub.data.repository

import com.example.foodhub.data.local.InitialData
import com.example.foodhub.data.local.MenuItemDao
import com.example.foodhub.data.local.OrderDao
import com.example.foodhub.data.model.MenuItemEntity
import com.example.foodhub.data.model.OrderEntity
import com.example.foodhub.data.model.OrderStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class FoodHubRepository(
    private val menuItemDao: MenuItemDao,
    private val orderDao: OrderDao
) {
    val allMenuItems: Flow<List<MenuItemEntity>> = menuItemDao.getAllMenuItems()
    val availableMenuItems: Flow<List<MenuItemEntity>> = menuItemDao.getAvailableMenuItems()
    val allOrders: Flow<List<OrderEntity>> = orderDao.getAllOrders()
    val totalRevenue: Flow<Double?> = orderDao.getTotalRevenue()

    fun getOrderById(orderId: Long): Flow<OrderEntity?> = orderDao.getOrderById(orderId)

    suspend fun ensureSeeded() = withContext(Dispatchers.IO) {
        if (menuItemDao.getCount() == 0) {
            menuItemDao.insertAll(InitialData.menuItems)
        }
        if (orderDao.getOrderCount() == 0) {
            InitialData.sampleOrders.forEach { orderDao.insertOrder(it) }
        }
    }

    suspend fun placeOrder(order: OrderEntity): Long = withContext(Dispatchers.IO) {
        orderDao.insertOrder(order)
    }

    suspend fun updateOrderStatus(orderId: Long, status: OrderStatus) = withContext(Dispatchers.IO) {
        orderDao.updateOrderStatus(orderId, status.name)
    }

    suspend fun toggleItemAvailability(id: Long, isAvailable: Boolean) = withContext(Dispatchers.IO) {
        menuItemDao.updateAvailability(id, isAvailable)
    }

    suspend fun saveMenuItem(item: MenuItemEntity): Long = withContext(Dispatchers.IO) {
        if (item.id == 0L) {
            menuItemDao.insertItem(item)
        } else {
            menuItemDao.updateItem(item)
            item.id
        }
    }

    suspend fun deleteMenuItem(id: Long) = withContext(Dispatchers.IO) {
        menuItemDao.deleteItemById(id)
    }
}
