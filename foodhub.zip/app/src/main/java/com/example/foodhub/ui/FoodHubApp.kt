package com.example.foodhub.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.foodhub.data.model.OrderEntity
import com.example.foodhub.data.model.OrderStatus
import com.example.foodhub.ui.business.RestaurantDashboardScreen
import com.example.foodhub.ui.components.FoodHubHeader
import com.example.foodhub.ui.customer.CartScreen
import com.example.foodhub.ui.customer.CheckoutDialog
import com.example.foodhub.ui.customer.CustomerHomeScreen
import com.example.foodhub.ui.customer.OrderTrackingScreen
import com.example.foodhub.ui.customer.ProductDetailDialog
import com.example.foodhub.ui.overview.FoodHubOverviewScreen
import com.example.foodhub.ui.viewmodel.AppMode
import com.example.foodhub.ui.viewmodel.CustomerSubScreen
import com.example.foodhub.ui.viewmodel.FoodHubViewModel

@Composable
fun FoodHubApp(
    viewModel: FoodHubViewModel = viewModel()
) {
    val currentMode by viewModel.appMode.collectAsStateWithLifecycle()
    val customerScreen by viewModel.customerScreen.collectAsStateWithLifecycle()
    val businessTab by viewModel.businessTab.collectAsStateWithLifecycle()

    val filteredMenu by viewModel.filteredCustomerMenu.collectAsStateWithLifecycle()
    val allMenuItems by viewModel.allMenuItems.collectAsStateWithLifecycle()
    val allOrders by viewModel.allOrders.collectAsStateWithLifecycle()

    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val cartSubtotal by viewModel.cartSubtotal.collectAsStateWithLifecycle()
    val cartTotal by viewModel.cartTotal.collectAsStateWithLifecycle()
    val discountAmount by viewModel.discountAmount.collectAsStateWithLifecycle()
    val promoMessage by viewModel.promoMessage.collectAsStateWithLifecycle()

    val checkoutForm by viewModel.checkoutForm.collectAsStateWithLifecycle()
    val activeTrackingId by viewModel.activeTrackingOrderId.collectAsStateWithLifecycle()
    val selectedProduct by viewModel.selectedProduct.collectAsStateWithLifecycle()

    var showCheckoutDialog by remember { mutableStateOf(false) }

    // Identify active order for customer tracking
    val trackedOrder: OrderEntity? = if (activeTrackingId != null) {
        allOrders.find { it.orderId == activeTrackingId }
    } else {
        allOrders.firstOrNull { it.status != OrderStatus.DELIVERED.name && it.status != OrderStatus.CANCELLED.name }
    }

    val hasActiveOrder = trackedOrder != null && trackedOrder.status != OrderStatus.DELIVERED.name && trackedOrder.status != OrderStatus.CANCELLED.name

    Scaffold(
        topBar = {
            FoodHubHeader(
                currentMode = currentMode,
                onModeSelected = { mode ->
                    viewModel.setAppMode(mode)
                },
                cartItemCount = cartItems.sumOf { it.quantity },
                onCartClick = {
                    viewModel.setAppMode(AppMode.CUSTOMER)
                    viewModel.navigateCustomer(CustomerSubScreen.CART)
                }
            )
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentMode) {
                AppMode.CUSTOMER -> {
                    when (customerScreen) {
                        CustomerSubScreen.MENU -> {
                            CustomerHomeScreen(
                                menuItems = filteredMenu,
                                selectedCategory = selectedCategory,
                                searchQuery = searchQuery,
                                onCategorySelected = { viewModel.setSelectedCategory(it) },
                                onSearchChanged = { viewModel.setSearchQuery(it) },
                                onItemClick = { viewModel.selectProduct(it) },
                                onQuickAddToCart = { viewModel.addToCart(it, quantity = 1) },
                                cartItems = cartItems,
                                cartSubtotal = cartSubtotal,
                                onViewCartClick = { viewModel.navigateCustomer(CustomerSubScreen.CART) },
                                onTrackOrderClick = {
                                    if (trackedOrder != null) {
                                        viewModel.setActiveTrackingOrderId(trackedOrder.orderId)
                                    } else {
                                        viewModel.navigateCustomer(CustomerSubScreen.ORDER_TRACKING)
                                    }
                                },
                                hasActiveOrder = hasActiveOrder
                            )
                        }

                        CustomerSubScreen.CART -> {
                            CartScreen(
                                cartItems = cartItems,
                                subtotal = cartSubtotal,
                                total = cartTotal,
                                discount = discountAmount,
                                promoMessage = promoMessage,
                                onQuantityChange = { id, delta -> viewModel.updateCartQuantity(id, delta) },
                                onApplyPromo = { viewModel.applyPromoCode(it) },
                                onClearCart = { viewModel.clearCart() },
                                onBackToMenu = { viewModel.navigateCustomer(CustomerSubScreen.MENU) },
                                onProceedToCheckout = { showCheckoutDialog = true }
                            )
                        }

                        CustomerSubScreen.ORDER_TRACKING -> {
                            OrderTrackingScreen(
                                order = trackedOrder,
                                onBackToMenu = { viewModel.navigateCustomer(CustomerSubScreen.MENU) },
                                onAdvanceStatus = { id, status -> viewModel.advanceOrderStatus(id, status) },
                                onViewRestaurantHub = { viewModel.setAppMode(AppMode.BUSINESS) }
                            )
                        }

                        else -> {
                            CustomerHomeScreen(
                                menuItems = filteredMenu,
                                selectedCategory = selectedCategory,
                                searchQuery = searchQuery,
                                onCategorySelected = { viewModel.setSelectedCategory(it) },
                                onSearchChanged = { viewModel.setSearchQuery(it) },
                                onItemClick = { viewModel.selectProduct(it) },
                                onQuickAddToCart = { viewModel.addToCart(it, quantity = 1) },
                                cartItems = cartItems,
                                cartSubtotal = cartSubtotal,
                                onViewCartClick = { viewModel.navigateCustomer(CustomerSubScreen.CART) },
                                onTrackOrderClick = { viewModel.navigateCustomer(CustomerSubScreen.ORDER_TRACKING) },
                                hasActiveOrder = hasActiveOrder
                            )
                        }
                    }
                }

                AppMode.BUSINESS -> {
                    RestaurantDashboardScreen(
                        currentTab = businessTab,
                        onTabSelected = { viewModel.setBusinessTab(it) },
                        orders = allOrders,
                        menuItems = allMenuItems,
                        onAdvanceOrderStatus = { id, status -> viewModel.advanceOrderStatus(id, status) },
                        onSetOrderStatus = { id, status -> viewModel.setOrderStatus(id, status) },
                        onToggleItemAvailability = { id, avail -> viewModel.toggleMenuItemAvailability(id, avail) },
                        onSaveMenuItem = { dish -> viewModel.saveMenuItem(dish) },
                        onDeleteMenuItem = { id -> viewModel.deleteMenuItem(id) }
                    )
                }

                AppMode.OVERVIEW -> {
                    FoodHubOverviewScreen(
                        onNavigateMode = { mode ->
                            viewModel.setAppMode(mode)
                            if (mode == AppMode.CUSTOMER) {
                                viewModel.navigateCustomer(CustomerSubScreen.MENU)
                            }
                        }
                    )
                }
            }
        }
    }

    // Product Detail Dialog
    selectedProduct?.let { product ->
        ProductDetailDialog(
            item = product,
            onDismiss = { viewModel.selectProduct(null) },
            onAddToCart = { qty, instructions ->
                viewModel.addToCart(product, quantity = qty, specialInstructions = instructions)
            }
        )
    }

    // Checkout Dialog
    if (showCheckoutDialog) {
        CheckoutDialog(
            form = checkoutForm,
            totalPayable = cartTotal,
            onFormChange = { update -> viewModel.updateCheckoutForm(update) },
            onDismiss = { showCheckoutDialog = false },
            onConfirmOrder = {
                viewModel.placeOrder { newOrderId ->
                    showCheckoutDialog = false
                }
            }
        )
    }
}
