package com.example.foodhub.data.model

data class CartItem(
    val menuItem: MenuItemEntity,
    val quantity: Int = 1,
    val specialInstructions: String = ""
) {
    val totalPrice: Double
        get() = menuItem.price * quantity
}
