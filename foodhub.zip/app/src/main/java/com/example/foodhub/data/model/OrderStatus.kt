package com.example.foodhub.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.ui.graphics.vector.ImageVector

enum class OrderStatus(
    val title: String,
    val description: String,
    val stepIndex: Int
) {
    PENDING("Order Received", "Order submitted to restaurant", 0),
    CONFIRMED("Confirmed", "Restaurant accepted your order", 1),
    PREPARING("Preparing", "Chef is cooking in the kitchen", 2),
    OUT_FOR_DELIVERY("Out for Delivery", "Courier is heading to your location", 3),
    DELIVERED("Delivered", "Delivered & ready to enjoy!", 4),
    CANCELLED("Cancelled", "Order was cancelled", -1);

    fun icon(): ImageVector = when (this) {
        PENDING -> Icons.Default.ReceiptLong
        CONFIRMED -> Icons.Default.Restaurant
        PREPARING -> Icons.Default.Kitchen
        OUT_FOR_DELIVERY -> Icons.Default.DeliveryDining
        DELIVERED -> Icons.Default.CheckCircle
        CANCELLED -> Icons.Default.ReceiptLong
    }

    fun nextStatus(): OrderStatus? = when (this) {
        PENDING -> CONFIRMED
        CONFIRMED -> PREPARING
        PREPARING -> OUT_FOR_DELIVERY
        OUT_FOR_DELIVERY -> DELIVERED
        DELIVERED -> null
        CANCELLED -> null
    }

    fun nextActionLabel(): String = when (this) {
        PENDING -> "Accept & Confirm"
        CONFIRMED -> "Start Kitchen Prep"
        PREPARING -> "Dispatch Delivery"
        OUT_FOR_DELIVERY -> "Complete & Deliver"
        DELIVERED -> "Completed"
        CANCELLED -> "Cancelled"
    }

    companion object {
        fun fromString(status: String): OrderStatus = try {
            valueOf(status)
        } catch (e: Exception) {
            PENDING
        }
    }
}
