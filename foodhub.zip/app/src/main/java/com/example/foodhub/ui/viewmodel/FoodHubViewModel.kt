package com.example.foodhub.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.foodhub.data.local.FoodHubDatabase
import com.example.foodhub.data.model.CartItem
import com.example.foodhub.data.model.MenuItemEntity
import com.example.foodhub.data.model.OrderEntity
import com.example.foodhub.data.model.OrderStatus
import com.example.foodhub.data.repository.FoodHubRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppMode(val label: String) {
    CUSTOMER("Order Food"),
    BUSINESS("Restaurant Hub"),
    OVERVIEW("Why FoodHub?")
}

enum class CustomerSubScreen {
    MENU,
    CART,
    CHECKOUT,
    ORDER_TRACKING,
    ORDER_HISTORY
}

enum class BusinessSubTab {
    ORDERS,
    MENU_MANAGEMENT,
    ANALYTICS
}

data class CheckoutForm(
    val name: String = "Alex Morgan",
    val phone: String = "+1 (555) 789-2026",
    val address: String = "42 Silicon Way, Innovation Park",
    val deliveryType: String = "Delivery",
    val paymentMethod: String = "Mobile Money",
    val notes: String = "Gate passcode: 1240. Leave at door."
)

class FoodHubViewModel(application: Application) : AndroidViewModel(application) {
    private val database = FoodHubDatabase.getDatabase(application, viewModelScope)
    private val repository = FoodHubRepository(database.menuItemDao(), database.orderDao())

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
        }
    }

    // App Mode
    private val _appMode = MutableStateFlow(AppMode.CUSTOMER)
    val appMode: StateFlow<AppMode> = _appMode.asStateFlow()

    fun setAppMode(mode: AppMode) {
        _appMode.value = mode
    }

    // Customer Navigation
    private val _customerScreen = MutableStateFlow(CustomerSubScreen.MENU)
    val customerScreen: StateFlow<CustomerSubScreen> = _customerScreen.asStateFlow()

    fun navigateCustomer(screen: CustomerSubScreen) {
        _customerScreen.value = screen
    }

    // Business SubTab
    private val _businessTab = MutableStateFlow(BusinessSubTab.ORDERS)
    val businessTab: StateFlow<BusinessSubTab> = _businessTab.asStateFlow()

    fun setBusinessTab(tab: BusinessSubTab) {
        _businessTab.value = tab
    }

    // Menu state
    val allMenuItems: StateFlow<List<MenuItemEntity>> = repository.allMenuItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val availableMenuItems: StateFlow<List<MenuItemEntity>> = repository.availableMenuItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allOrders: StateFlow<List<OrderEntity>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search and category filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    // Filtered menu for customer
    val filteredCustomerMenu: StateFlow<List<MenuItemEntity>> = combine(
        availableMenuItems,
        _selectedCategory,
        _searchQuery
    ) { items, cat, query ->
        items.filter { item ->
            val matchesCategory = (cat == "All" || item.category.equals(cat, ignoreCase = true))
            val matchesQuery = query.isBlank() ||
                    item.name.contains(query, ignoreCase = true) ||
                    item.description.contains(query, ignoreCase = true) ||
                    item.tags.contains(query, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Cart Management
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    private val _promoCode = MutableStateFlow("")
    val promoCode: StateFlow<String> = _promoCode.asStateFlow()

    private val _discountAmount = MutableStateFlow(0.0)
    val discountAmount: StateFlow<Double> = _discountAmount.asStateFlow()

    private val _promoMessage = MutableStateFlow<String?>(null)
    val promoMessage: StateFlow<String?> = _promoMessage.asStateFlow()

    val cartSubtotal: StateFlow<Double> = combine(_cartItems) { items ->
        items[0].sumOf { it.totalPrice }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val cartTotal: StateFlow<Double> = combine(cartSubtotal, _discountAmount) { subtotal, discount ->
        if (subtotal == 0.0) 0.0 else maxOf(0.0, subtotal + 2.50 - discount)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun addToCart(item: MenuItemEntity, quantity: Int = 1, specialInstructions: String = "") {
        val current = _cartItems.value.toMutableList()
        val existingIndex = current.indexOfFirst { it.menuItem.id == item.id }
        if (existingIndex >= 0) {
            val existing = current[existingIndex]
            current[existingIndex] = existing.copy(
                quantity = existing.quantity + quantity,
                specialInstructions = if (specialInstructions.isNotBlank()) specialInstructions else existing.specialInstructions
            )
        } else {
            current.add(CartItem(menuItem = item, quantity = quantity, specialInstructions = specialInstructions))
        }
        _cartItems.value = current
    }

    fun updateCartQuantity(itemId: Long, delta: Int) {
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.menuItem.id == itemId }
        if (index >= 0) {
            val updated = current[index].quantity + delta
            if (updated <= 0) {
                current.removeAt(index)
            } else {
                current[index] = current[index].copy(quantity = updated)
            }
            _cartItems.value = current
        }
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        _promoCode.value = ""
        _discountAmount.value = 0.0
        _promoMessage.value = null
    }

    fun applyPromoCode(code: String) {
        _promoCode.value = code
        val trimmed = code.trim().uppercase()
        when (trimmed) {
            "FOODHUB15" -> {
                val subtotal = _cartItems.value.sumOf { it.totalPrice }
                _discountAmount.value = (subtotal * 0.15).let { Math.round(it * 100.0) / 100.0 }
                _promoMessage.value = "15% FoodHub Digital discount applied!"
            }
            "WELCOME10" -> {
                val subtotal = _cartItems.value.sumOf { it.totalPrice }
                _discountAmount.value = minOf(subtotal, 5.00)
                _promoMessage.value = "$5 Welcome voucher applied!"
            }
            else -> {
                _discountAmount.value = 0.0
                _promoMessage.value = "Invalid promo code. Try 'FOODHUB15' or 'WELCOME10'"
            }
        }
    }

    // Checkout form
    private val _checkoutForm = MutableStateFlow(CheckoutForm())
    val checkoutForm: StateFlow<CheckoutForm> = _checkoutForm.asStateFlow()

    fun updateCheckoutForm(update: (CheckoutForm) -> CheckoutForm) {
        _checkoutForm.value = update(_checkoutForm.value)
    }

    // Active Tracking Order ID
    private val _activeTrackingOrderId = MutableStateFlow<Long?>(null)
    val activeTrackingOrderId: StateFlow<Long?> = _activeTrackingOrderId.asStateFlow()

    fun setActiveTrackingOrderId(id: Long?) {
        _activeTrackingOrderId.value = id
        if (id != null) {
            _customerScreen.value = CustomerSubScreen.ORDER_TRACKING
        }
    }

    // Place Order
    fun placeOrder(onSuccess: (Long) -> Unit) {
        val items = _cartItems.value
        if (items.isEmpty()) return

        val form = _checkoutForm.value
        val subtotal = items.sumOf { it.totalPrice }
        val discount = _discountAmount.value
        val deliveryFee = if (form.deliveryType == "Delivery") 2.50 else 0.0
        val total = maxOf(0.0, subtotal + deliveryFee - discount)

        val summary = items.joinToString(", ") { "${it.quantity}x ${it.menuItem.name}" }

        val order = OrderEntity(
            customerName = form.name.ifBlank { "Guest Customer" },
            customerPhone = form.phone.ifBlank { "+1 (555) 000-0000" },
            deliveryAddress = if (form.deliveryType == "Delivery") form.address.ifBlank { "Pickup counter" } else form.deliveryType,
            deliveryType = form.deliveryType,
            paymentMethod = form.paymentMethod,
            status = OrderStatus.PENDING.name,
            itemsSummary = summary,
            subtotal = subtotal,
            deliveryFee = deliveryFee,
            discount = discount,
            totalAmount = total,
            orderTimeMillis = System.currentTimeMillis(),
            notes = form.notes,
            estimatedDeliveryMinutes = 25
        )

        viewModelScope.launch {
            val newId = repository.placeOrder(order)
            clearCart()
            _activeTrackingOrderId.value = newId
            _customerScreen.value = CustomerSubScreen.ORDER_TRACKING
            onSuccess(newId)
        }
    }

    // Business actions: Order Status Update
    fun advanceOrderStatus(orderId: Long, currentStatus: OrderStatus) {
        val next = currentStatus.nextStatus() ?: return
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, next)
        }
    }

    fun setOrderStatus(orderId: Long, status: OrderStatus) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, status)
        }
    }

    // Business actions: Menu Item Management
    fun toggleMenuItemAvailability(id: Long, isAvailable: Boolean) {
        viewModelScope.launch {
            repository.toggleItemAvailability(id, isAvailable)
        }
    }

    fun saveMenuItem(item: MenuItemEntity) {
        viewModelScope.launch {
            repository.saveMenuItem(item)
        }
    }

    fun deleteMenuItem(id: Long) {
        viewModelScope.launch {
            repository.deleteMenuItem(id)
        }
    }

    // Selected item for product detail sheet
    private val _selectedProduct = MutableStateFlow<MenuItemEntity?>(null)
    val selectedProduct: StateFlow<MenuItemEntity?> = _selectedProduct.asStateFlow()

    fun selectProduct(item: MenuItemEntity?) {
        _selectedProduct.value = item
    }
}
