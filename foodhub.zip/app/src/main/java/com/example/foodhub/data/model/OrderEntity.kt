package com.example.foodhub.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true)
    val orderId: Long = 0,
    val customerName: String,
    val customerPhone: String,
    val deliveryAddress: String,
    val deliveryType: String = "Delivery", // "Delivery", "Pickup", "Table Dine-in"
    val paymentMethod: String = "Mobile Money", // "Mobile Money", "Card", "Cash on Delivery"
    val status: String = "PENDING", // PENDING, CONFIRMED, PREPARING, OUT_FOR_DELIVERY, DELIVERED, CANCELLED
    val itemsSummary: String,
    val itemsJson: String = "",
    val subtotal: Double,
    val deliveryFee: Double = 2.50,
    val discount: Double = 0.0,
    val totalAmount: Double,
    val orderTimeMillis: Long = System.currentTimeMillis(),
    val notes: String = "",
    val estimatedDeliveryMinutes: Int = 30
)
