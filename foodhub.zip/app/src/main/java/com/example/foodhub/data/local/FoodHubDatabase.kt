package com.example.foodhub.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.foodhub.data.model.MenuItemEntity
import com.example.foodhub.data.model.OrderEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [MenuItemEntity::class, OrderEntity::class],
    version = 1,
    exportSchema = false
)
abstract class FoodHubDatabase : RoomDatabase() {
    abstract fun menuItemDao(): MenuItemDao
    abstract fun orderDao(): OrderDao

    companion object {
        @Volatile
        private var INSTANCE: FoodHubDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): FoodHubDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FoodHubDatabase::class.java,
                    "foodhub_database"
                )
                .addCallback(FoodHubDatabaseCallback(scope))
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class FoodHubDatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.menuItemDao(), database.orderDao())
                    }
                }
            }

            suspend fun populateInitialData(menuDao: MenuItemDao, orderDao: OrderDao) {
                if (menuDao.getCount() == 0) {
                    menuDao.insertAll(InitialData.menuItems)
                }
                if (orderDao.getOrderCount() == 0) {
                    InitialData.sampleOrders.forEach { orderDao.insertOrder(it) }
                }
            }
        }
    }
}

object InitialData {
    val menuItems = listOf(
        MenuItemEntity(
            name = "FoodHub Wagyu Deluxe",
            category = "Burgers",
            description = "Prime wagyu patty, aged white cheddar, caramelized onion relish, truffle aioli on toasted brioche.",
            price = 14.50,
            isAvailable = true,
            isPopular = true,
            prepTimeMinutes = 15,
            rating = 4.9,
            calories = 680,
            tags = "Chef Special • Wagyu"
        ),
        MenuItemEntity(
            name = "Crispy Hot Honey Chicken",
            category = "Burgers",
            description = "Double-dredged spiced chicken thigh, habanero hot honey drizzle, crunchy dill slaw & garlic pickles.",
            price = 12.00,
            isAvailable = true,
            isPopular = true,
            prepTimeMinutes = 12,
            rating = 4.8,
            calories = 620,
            tags = "Spicy • Best Seller"
        ),
        MenuItemEntity(
            name = "Smash Bacon Double",
            category = "Burgers",
            description = "Twin smashed Angus beef patties, applewood bacon, melty American cheese, and signature secret sauce.",
            price = 11.50,
            isAvailable = true,
            isPopular = false,
            prepTimeMinutes = 10,
            rating = 4.7,
            calories = 710,
            tags = "Classic • Angus"
        ),
        MenuItemEntity(
            name = "Truffle Wild Mushroom Pizza",
            category = "Pizzas",
            description = "Hand-stretched 48-hr fermented dough, roasted cremini & shiitake mushrooms, fior di latte, white truffle oil.",
            price = 16.00,
            isAvailable = true,
            isPopular = true,
            prepTimeMinutes = 18,
            rating = 4.9,
            calories = 820,
            tags = "Vegetarian • Wood-fired"
        ),
        MenuItemEntity(
            name = "Spicy Diavola Pepperoni",
            category = "Pizzas",
            description = "San Marzano D.O.P. sauce, artisanal spicy salami, hot Calabrian chili paste, fresh mozzarella, fresh oregano.",
            price = 15.00,
            isAvailable = true,
            isPopular = true,
            prepTimeMinutes = 16,
            rating = 4.8,
            calories = 860,
            tags = "Spicy • Crowd Favorite"
        ),
        MenuItemEntity(
            name = "Classic Margherita D.O.P.",
            category = "Pizzas",
            description = "Buffalo mozzarella campana, slow-simmered tomato sauce, sweet garden basil, cold-pressed olive oil.",
            price = 13.00,
            isAvailable = true,
            isPopular = false,
            prepTimeMinutes = 14,
            rating = 4.6,
            calories = 740,
            tags = "Vegetarian • Traditional"
        ),
        MenuItemEntity(
            name = "Grilled Salmon Quinoa Bowl",
            category = "Bowls",
            description = "Pan-seared Atlantic salmon fillet, fluffy tri-color quinoa, Hass avocado, edamame, yuzu sesame glaze.",
            price = 15.50,
            isAvailable = true,
            isPopular = true,
            prepTimeMinutes = 15,
            rating = 4.9,
            calories = 510,
            tags = "High Protein • Healthy"
        ),
        MenuItemEntity(
            name = "Mediterranean Herb Chicken Bowl",
            category = "Bowls",
            description = "Oregano-grilled chicken breast, cucumber salad, kalamata olives, creamy feta cheese, brown rice, herb tzatziki.",
            price = 13.50,
            isAvailable = true,
            isPopular = false,
            prepTimeMinutes = 12,
            rating = 4.7,
            calories = 490,
            tags = "Gluten Free Option • Fresh"
        ),
        MenuItemEntity(
            name = "Cold Brew Nitro Coffee",
            category = "Beverages",
            description = "Velvety nitrogen-infused single origin Ethiopian cold brew, naturally sweet crema head.",
            price = 5.00,
            isAvailable = true,
            isPopular = false,
            prepTimeMinutes = 3,
            rating = 4.8,
            calories = 15,
            tags = "Cold Brew • Zero Sugar"
        ),
        MenuItemEntity(
            name = "Sparkling Mango Passion Cooler",
            category = "Beverages",
            description = "Fresh Alphonso mango pulp, crushed passionfruit, fresh mint leaves, lime twist and sparkling mineral water.",
            price = 4.50,
            isAvailable = true,
            isPopular = true,
            prepTimeMinutes = 5,
            rating = 4.9,
            calories = 120,
            tags = "Refreshing • Natural"
        ),
        MenuItemEntity(
            name = "Madagascar Vanilla Gelato Shake",
            category = "Beverages",
            description = "Hand-spun bourbon vanilla bean gelato, farm-fresh whole milk, whipped cream, butter waffle cone shard.",
            price = 6.00,
            isAvailable = true,
            isPopular = false,
            prepTimeMinutes = 5,
            rating = 4.7,
            calories = 380,
            tags = "Gelato • Sweet"
        ),
        MenuItemEntity(
            name = "Warm Belgian Chocolate Lava Cake",
            category = "Desserts",
            description = "Rich 70% dark chocolate souffle with flowing warm chocolate center, served with powdered sugar.",
            price = 7.50,
            isAvailable = true,
            isPopular = true,
            prepTimeMinutes = 10,
            rating = 4.9,
            calories = 440,
            tags = "Decadent • Fresh Baked"
        ),
        MenuItemEntity(
            name = "Crispy Churros & Dulce de Leche",
            category = "Desserts",
            description = "Spanish style fried dough batons dusted in cinnamon cassia sugar, served with warm dulce de leche dip.",
            price = 6.50,
            isAvailable = true,
            isPopular = false,
            prepTimeMinutes = 8,
            rating = 4.7,
            calories = 360,
            tags = "Shareable • Cinnamon"
        )
    )

    val sampleOrders = listOf(
        OrderEntity(
            customerName = "Sarah Jenkins",
            customerPhone = "+1 (555) 234-8901",
            deliveryAddress = "742 Evergreen Terrace, Apt 3B",
            deliveryType = "Delivery",
            paymentMethod = "Mobile Money",
            status = "PENDING",
            itemsSummary = "1x FoodHub Wagyu Deluxe, 1x Sparkling Mango Passion Cooler",
            subtotal = 19.00,
            deliveryFee = 2.50,
            discount = 0.0,
            totalAmount = 21.50,
            orderTimeMillis = System.currentTimeMillis() - 4 * 60 * 1000,
            notes = "Please leave at front doorstep and ring bell.",
            estimatedDeliveryMinutes = 25
        ),
        OrderEntity(
            customerName = "Michael Chen",
            customerPhone = "+1 (555) 456-1234",
            deliveryAddress = "1208 Pine Crest Ave, Suite 10",
            deliveryType = "Delivery",
            paymentMethod = "Card",
            status = "PREPARING",
            itemsSummary = "1x Truffle Wild Mushroom Pizza, 1x Cold Brew Nitro Coffee",
            subtotal = 21.00,
            deliveryFee = 2.50,
            discount = 2.00,
            totalAmount = 21.50,
            orderTimeMillis = System.currentTimeMillis() - 14 * 60 * 1000,
            notes = "Extra hot pizza please.",
            estimatedDeliveryMinutes = 18
        ),
        OrderEntity(
            customerName = "Amina Diallo",
            customerPhone = "+1 (555) 789-5678",
            deliveryAddress = "450 Market Street, 4th Floor",
            deliveryType = "Delivery",
            paymentMethod = "Mobile Money",
            status = "OUT_FOR_DELIVERY",
            itemsSummary = "1x Grilled Salmon Quinoa Bowl, 1x Warm Belgian Chocolate Lava Cake",
            subtotal = 23.00,
            deliveryFee = 2.50,
            discount = 0.0,
            totalAmount = 25.50,
            orderTimeMillis = System.currentTimeMillis() - 25 * 60 * 1000,
            notes = "Security will buzz courier up.",
            estimatedDeliveryMinutes = 8
        ),
        OrderEntity(
            customerName = "David Miller",
            customerPhone = "+1 (555) 321-9876",
            deliveryAddress = "88 Sunset Blvd",
            deliveryType = "Takeout",
            paymentMethod = "Cash on Delivery",
            status = "DELIVERED",
            itemsSummary = "2x Crispy Hot Honey Chicken, 2x Madagascar Vanilla Gelato Shake",
            subtotal = 36.00,
            deliveryFee = 0.0,
            discount = 5.00,
            totalAmount = 31.00,
            orderTimeMillis = System.currentTimeMillis() - 65 * 60 * 1000,
            notes = "Customer picked up at counter.",
            estimatedDeliveryMinutes = 0
        )
    )
}
