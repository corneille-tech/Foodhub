package com.example.foodhub.ui.business

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.foodhub.data.model.MenuItemEntity
import com.example.foodhub.data.model.OrderEntity
import com.example.foodhub.data.model.OrderStatus
import com.example.foodhub.ui.viewmodel.BusinessSubTab
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RestaurantDashboardScreen(
    currentTab: BusinessSubTab,
    onTabSelected: (BusinessSubTab) -> Unit,
    orders: List<OrderEntity>,
    menuItems: List<MenuItemEntity>,
    onAdvanceOrderStatus: (Long, OrderStatus) -> Unit,
    onSetOrderStatus: (Long, OrderStatus) -> Unit,
    onToggleItemAvailability: (Long, Boolean) -> Unit,
    onSaveMenuItem: (MenuItemEntity) -> Unit,
    onDeleteMenuItem: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var itemBeingEdited by remember { mutableStateOf<MenuItemEntity?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var orderStatusFilter by remember { mutableStateOf("ALL") }

    // Analytics calculations
    val validOrders = orders.filter { it.status != "CANCELLED" }
    val totalRevenue = validOrders.sumOf { it.totalAmount }
    val activeOrdersCount = orders.count { it.status in listOf("PENDING", "CONFIRMED", "PREPARING", "OUT_FOR_DELIVERY") }
    val completedOrdersCount = orders.count { it.status == "DELIVERED" }
    val averageTicketSize = if (validOrders.isNotEmpty()) totalRevenue / validOrders.size else 0.0

    Scaffold(
        floatingActionButton = {
            if (currentTab == BusinessSubTab.MENU_MANAGEMENT) {
                FloatingActionButton(
                    onClick = { showAddDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("fab_add_dish")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add Dish")
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Dashboard KPI Header Cards
            MetricsHeaderCards(
                revenue = totalRevenue,
                activeCount = activeOrdersCount,
                completedCount = completedOrdersCount,
                avgTicket = averageTicketSize
            )

            // Business Navigation Tabs
            TabRow(
                selectedTabIndex = currentTab.ordinal,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                Tab(
                    selected = currentTab == BusinessSubTab.ORDERS,
                    onClick = { onTabSelected(BusinessSubTab.ORDERS) },
                    modifier = Modifier.testTag("business_tab_orders"),
                    text = {
                        Text(
                            text = "Orders (${orders.size})",
                            fontWeight = if (currentTab == BusinessSubTab.ORDERS) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                )
                Tab(
                    selected = currentTab == BusinessSubTab.MENU_MANAGEMENT,
                    onClick = { onTabSelected(BusinessSubTab.MENU_MANAGEMENT) },
                    modifier = Modifier.testTag("business_tab_menu"),
                    text = {
                        Text(
                            text = "Menu & Dishes",
                            fontWeight = if (currentTab == BusinessSubTab.MENU_MANAGEMENT) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                )
                Tab(
                    selected = currentTab == BusinessSubTab.ANALYTICS,
                    onClick = { onTabSelected(BusinessSubTab.ANALYTICS) },
                    modifier = Modifier.testTag("business_tab_analytics"),
                    text = {
                        Text(
                            text = "Sales Activity",
                            fontWeight = if (currentTab == BusinessSubTab.ANALYTICS) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                )
            }

            // Tab Content
            when (currentTab) {
                BusinessSubTab.ORDERS -> {
                    OrdersPipelineView(
                        orders = orders,
                        statusFilter = orderStatusFilter,
                        onFilterChange = { orderStatusFilter = it },
                        onAdvanceStatus = onAdvanceOrderStatus,
                        onCancelOrder = { id -> onSetOrderStatus(id, OrderStatus.CANCELLED) }
                    )
                }
                BusinessSubTab.MENU_MANAGEMENT -> {
                    MenuManagementView(
                        items = menuItems,
                        onToggleAvailability = onToggleItemAvailability,
                        onEditItem = { itemBeingEdited = it },
                        onDeleteItem = onDeleteMenuItem
                    )
                }
                BusinessSubTab.ANALYTICS -> {
                    SalesActivityView(
                        orders = orders,
                        menuItems = menuItems,
                        totalRevenue = totalRevenue,
                        activeOrders = activeOrdersCount,
                        completedOrders = completedOrdersCount
                    )
                }
            }
        }
    }

    // Add / Edit Dish Dialog
    if (showAddDialog || itemBeingEdited != null) {
        AddEditDishDialog(
            itemToEdit = itemBeingEdited,
            onDismiss = {
                showAddDialog = false
                itemBeingEdited = null
            },
            onSaveItem = { dish ->
                onSaveMenuItem(dish)
                showAddDialog = false
                itemBeingEdited = null
            }
        )
    }
}

@Composable
fun MetricsHeaderCards(
    revenue: Double,
    activeCount: Int,
    completedCount: Int,
    avgTicket: Double
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Revenue Card
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AttachMoney,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Today's Sales",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = String.format(Locale.US, "$%.2f", revenue),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }

            // Active Orders Card
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Kitchen,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Active Orders",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "$activeCount",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                }
            }

            // Avg Ticket Card
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.TrendingUp,
                            contentDescription = null,
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Avg Ticket",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = String.format(Locale.US, "$%.2f", avgTicket),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun OrdersPipelineView(
    orders: List<OrderEntity>,
    statusFilter: String,
    onFilterChange: (String) -> Unit,
    onAdvanceStatus: (Long, OrderStatus) -> Unit,
    onCancelOrder: (Long) -> Unit
) {
    val filters = listOf("ALL", "PENDING", "CONFIRMED", "PREPARING", "OUT_FOR_DELIVERY", "DELIVERED")

    val filteredOrders = orders.filter { order ->
        if (statusFilter == "ALL") true else order.status == statusFilter
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(filters) { filter ->
                    val isSelected = statusFilter == filter
                    FilterChip(
                        selected = isSelected,
                        onClick = { onFilterChange(filter) },
                        label = {
                            val count = if (filter == "ALL") orders.size else orders.count { it.status == filter }
                            Text("$filter ($count)", fontSize = 11.sp)
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }
        }

        if (filteredOrders.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "No orders in \"$statusFilter\" state.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(filteredOrders, key = { it.orderId }) { order ->
                val status = OrderStatus.fromString(order.status)
                val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
                val orderTime = timeFormat.format(Date(order.orderTimeMillis))

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        // Order Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "#FH-${order.orderId}",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "• $orderTime",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = "${order.customerName} (${order.customerPhone})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            // Status Chip
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = when (status) {
                                    OrderStatus.PENDING -> Color(0xFFFFF8E1)
                                    OrderStatus.CONFIRMED -> Color(0xFFE8F5E9)
                                    OrderStatus.PREPARING -> Color(0xFFFFECE0)
                                    OrderStatus.OUT_FOR_DELIVERY -> Color(0xFFE3F2FD)
                                    OrderStatus.DELIVERED -> Color(0xFFE8F5E9)
                                    OrderStatus.CANCELLED -> Color(0xFFFFEBEE)
                                }
                            ) {
                                Text(
                                    text = status.title,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = when (status) {
                                        OrderStatus.PENDING -> Color(0xFFF57F17)
                                        OrderStatus.CONFIRMED -> Color(0xFF2E7D32)
                                        OrderStatus.PREPARING -> Color(0xFFE65100)
                                        OrderStatus.OUT_FOR_DELIVERY -> Color(0xFF1976D2)
                                        OrderStatus.DELIVERED -> Color(0xFF2E7D32)
                                        OrderStatus.CANCELLED -> Color(0xFFC62828)
                                    }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Items & Notes
                        Text(
                            text = order.itemsSummary,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        if (order.notes.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Instructions: \"${order.notes}\"",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${order.deliveryType} • ${order.paymentMethod}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Text(
                                text = String.format(Locale.US, "$%.2f", order.totalAmount),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                        }

                        // Order Action Buttons
                        if (status != OrderStatus.DELIVERED && status != OrderStatus.CANCELLED) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { onCancelOrder(order.orderId) },
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text("Cancel", color = MaterialTheme.colorScheme.error)
                                }

                                Button(
                                    onClick = { onAdvanceStatus(order.orderId, status) },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = status.nextActionLabel(),
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MenuManagementView(
    items: List<MenuItemEntity>,
    onToggleAvailability: (Long, Boolean) -> Unit,
    onEditItem: (MenuItemEntity) -> Unit,
    onDeleteItem: (Long) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Menu Items Catalog (${items.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Toggle availability or add items",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        items(items, key = { it.id }) { item ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = item.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = item.category,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp)
                                )
                            }
                        }

                        Text(
                            text = String.format(Locale.US, "$%.2f • %d mins prep • %d kcal", item.price, item.prepTimeMinutes, item.calories),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Stock availability toggle
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(
                            checked = item.isAvailable,
                            onCheckedChange = { onToggleAvailability(item.id, it) },
                            modifier = Modifier.testTag("toggle_stock_${item.id}")
                        )

                        IconButton(
                            onClick = { onEditItem(item) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit item",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(
                            onClick = { onDeleteItem(item.id) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete item",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SalesActivityView(
    orders: List<OrderEntity>,
    menuItems: List<MenuItemEntity>,
    totalRevenue: Double,
    activeOrders: Int,
    completedOrders: Int
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Business Activity & Growth Analytics",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "Digital operations intelligence vs traditional manual tracking",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Summary Breakdown Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Sales Performance Overview",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    MetricRow("Total Processed Orders", "${orders.size} orders")
                    MetricRow("Completed & Delivered", "$completedOrders orders")
                    MetricRow("Active Pipeline Orders", "$activeOrders in prep/delivery")
                    MetricRow("Digital Revenue Generated", String.format(Locale.US, "$%.2f", totalRevenue))
                    MetricRow("Average Order Basket", String.format(Locale.US, "$%.2f", if (orders.isNotEmpty()) totalRevenue / orders.size else 0.0))
                }
            }
        }

        // Category Breakdown Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Menu Distribution by Category",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    val categories = listOf("Burgers", "Pizzas", "Bowls", "Beverages", "Desserts")
                    categories.forEach { cat ->
                        val count = menuItems.count { it.category == cat }
                        val active = menuItems.count { it.category == cat && it.isAvailable }
                        MetricRow(cat, "$active of $count available")
                    }
                }
            }
        }

        // Digital Transformation Advantages Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "FoodHub Growth Advantages",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• Instant menu updates without reprinting costs\n" +
                                "• Centralized digital order processing reduces confusion\n" +
                                "• Real-time financial visibility with automated sales totals\n" +
                                "• Seamless customer self-ordering increases throughput",
                        style = MaterialTheme.typography.bodySmall,
                        lineHeight = 20.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun MetricRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
    }
}
