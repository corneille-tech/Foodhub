package com.example.foodhub.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "menu_items")
data class MenuItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String,
    val description: String,
    val price: Double,
    val isAvailable: Boolean = true,
    val isPopular: Boolean = false,
    val prepTimeMinutes: Int = 15,
    val rating: Double = 4.8,
    val calories: Int = 450,
    val tags: String = "Popular"
)
