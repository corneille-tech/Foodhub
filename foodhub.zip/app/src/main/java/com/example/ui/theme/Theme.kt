package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val FoodHubDarkColorScheme = darkColorScheme(
    primary = FoodHubOrangeLight,
    onPrimary = Color(0xFF3E1500),
    primaryContainer = FoodHubOrangeDark,
    onPrimaryContainer = Color(0xFFFFDBCF),
    secondary = FoodHubAmber,
    onSecondary = Color(0xFF402D00),
    secondaryContainer = Color(0xFF5C4300),
    onSecondaryContainer = FoodHubAmberContainer,
    tertiary = FoodHubGreenSuccess,
    background = FoodHubDarkBg,
    onBackground = FoodHubTextPrimaryLight,
    surface = FoodHubDarkSurface,
    onSurface = FoodHubTextPrimaryLight,
    surfaceVariant = FoodHubDarkSurfaceVariant,
    onSurfaceVariant = FoodHubTextSecondaryLight
)

private val FoodHubLightColorScheme = lightColorScheme(
    primary = FoodHubOrangePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFEBE3),
    onPrimaryContainer = FoodHubOrangeDark,
    secondary = FoodHubAmber,
    onSecondary = Color.Black,
    secondaryContainer = FoodHubAmberContainer,
    onSecondaryContainer = Color(0xFF332000),
    tertiary = FoodHubGreenSuccess,
    background = FoodHubLightBg,
    onBackground = FoodHubTextPrimaryDark,
    surface = FoodHubLightSurface,
    onSurface = FoodHubTextPrimaryDark,
    surfaceVariant = FoodHubLightSurfaceVariant,
    onSurfaceVariant = FoodHubTextSecondaryDark
)

@Composable
fun FoodHubTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep FoodHub's distinctive brand identity
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> FoodHubDarkColorScheme
        else -> FoodHubLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Keep MyApplicationTheme alias for existing screenshot test compatibility
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    FoodHubTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}
