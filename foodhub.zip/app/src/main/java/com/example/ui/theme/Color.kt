package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// FoodHub Brand Palette - Warm Culinary & Modern Digital
val FoodHubOrangePrimary = Color(0xFFFF5722)
val FoodHubOrangeDark = Color(0xFFD84315)
val FoodHubOrangeLight = Color(0xFFFF8A65)
val FoodHubAmber = Color(0xFFFFB300)
val FoodHubAmberContainer = Color(0xFFFFECB3)

val FoodHubDarkBg = Color(0xFF141210)
val FoodHubDarkSurface = Color(0xFF1E1B18)
val FoodHubDarkSurfaceVariant = Color(0xFF2C2723)

val FoodHubLightBg = Color(0xFFFBF9F6)
val FoodHubLightSurface = Color(0xFFFFFFFF)
val FoodHubLightSurfaceVariant = Color(0xFFF3ECE4)

val FoodHubGreenSuccess = Color(0xFF2E7D32)
val FoodHubGreenContainer = Color(0xFFE8F5E9)

val FoodHubBlueInfo = Color(0xFF1976D2)
val FoodHubBlueContainer = Color(0xFFE3F2FD)

val FoodHubTextPrimaryDark = Color(0xFF1A1715)
val FoodHubTextSecondaryDark = Color(0xFF6B6560)
val FoodHubTextPrimaryLight = Color(0xFFF8F5F2)
val FoodHubTextSecondaryLight = Color(0xFFAFA9A2)

val FoodHubCardBorder = Color(0xFFE8E0D7)
val FoodHubChipSelected = Color(0xFFFF5722)
